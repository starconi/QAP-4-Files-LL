# Description: Enter and calculate the One Stop Insurance Companies new insurnace policy information.
# Author: Landon
# Date(s): March 14 - March 28, 2025


# Define required libraries.
import datetime
import FormatValues as FV
import time
import sys
import os


# Define program constants.
POL_NUM = 1944
BASIC_PREMIUM = 869.00
ADD_CAR_DISC = .25
EXT_LIA_COV = 130.00
GLASS_COV = 86.00
LOAN_CAR_COV = 58.00
HST = .15
MON_PROC_FEE = 39.99

VAL_PROV = ["AB", "BC", "MB", "NB", "NL", "NS", "NT", "NU", "ON", "PE", "QC", "SK", "YT"]
VAL_PAY_METHOD = ["FULL", "MONTHLY", "DOWN PAY"]

# Main program starts here.
PolicyNum = POL_NUM
while True:
    
    # Gather user inputs.
    FirstName = input("Enter the customer first name: ").title()
    LastName = input("Enter the customers last name: ").title()
    StAdd = input("Enter the customers street address: ")
    City = input("Enter the customers city: ").title()

    Prov = FV.ValidateInput("Enter the customers province: ", VAL_PROV).upper()

    PosCode = input("Enter the customers postal code: ")
    PhoneNum = input("Enter the customers phone number: ")

    CarNum = int(input("Enter the amount of cars being insured: "))
    ExtLia = input("Does the customer want extra liability up to $1,000,000 (Y/N): ").upper()
    OpGlassCov = input("Does the customer want glass coverage (Y/N): ").upper()
    LoanCar = input("Does the customer want a loaner car (Y/N): ").upper()

    PayMethod = FV.ValidateInput("Does the customer want to pay in full or monthly (Full, Monthly or Down Pay): ", VAL_PAY_METHOD).title()
    DownPay = 0
    if PayMethod == "Down Pay":
        DownPay = float(input("Enter the down payment amount: "))

    # Claims
    claims = []
    ClaimNum = input("Enter the claim number (END to finsih): ")
    if ClaimNum.upper() == "END":
        break
    ClaimDate = input("Enter the claim date: ")
    ClaimAmt = float(input("Enter the claim amount: "))
    claims.append((ClaimNum, ClaimDate, ClaimAmt))


    # Perform required calculations.
    BasePrem = BASIC_PREMIUM + (CarNum - 1) * BASIC_PREMIUM * (1 - ADD_CAR_DISC)

    # Found out that backslashs can be used as line continuations, using here in the extras calculations
    ExtOpt = CarNum * (EXT_LIA_COV if ExtLia == "Y" else 0) + \
             CarNum * (GLASS_COV if OpGlassCov == "Y" else 0) +\
             CarNum * (LOAN_CAR_COV if LoanCar == "Y" else 0)
    
    # Totals calculations
    TotPrem = BasePrem + ExtOpt
    Tax = TotPrem * HST
    TotCost = TotPrem + Tax

    # Payment method calculations
    if PayMethod == "Full":
        MonPay = 0
        ProcFee = 0
    elif PayMethod == "Monthly":
        ProcFee = MON_PROC_FEE
        MonPay = (TotCost + ProcFee) / 8
    elif PayMethod == "Down Pay":
        RemCost = TotCost - DownPay
        ProcFee = MON_PROC_FEE
        MonPay = (RemCost + ProcFee) / 8

    # Dates calculations
    InvDate = datetime.datetime.now()
    FirPayDate = InvDate + datetime.timedelta(days = 20)
    if FirPayDate.day > 1:
        FirPayDate = FirPayDate.replace(day = 1) + datetime.timedelta(days = 31)
        FirPayDate = FirPayDate.replace(day = 1)
        
    # Display results for invoice
    print()
    print(f"           One Stop Insurance                                  ")
    print(f"                Invoice                                        ")
    print(f"------------------------------------------                     ")
    print(f"Customer name: {FirstName}, {LastName}                         ")
    print()
    print(f"Customer address: {StAdd}                                      ")
    print(f"                  {City}, {Prov} {PosCode}                     ")
    print()
    print(f"Phone number: {PhoneNum}                                       ")
    print(f"------------------------------------------                     ")
    print(f"Cars insured:                        {CarNum}                  ")
    print(f"Base premium:                    ${BasePrem:.2f}               ")
    print(f"Extra costs:                     ${ExtOpt:.2f}                 ")
    print(f"Total Premium:                   ${TotPrem:.2f}                ")
    print(f"HST:                             ${Tax:.2f}                    ")
    print(f"Total cost:                      ${TotCost:.2f}                ")
    if PayMethod == "Down Pay":
        print(f"Down payment:                      ${DownPay:.2f}          ")
        print(f"Remaining Cost:                    ${RemCost:.2f}          ")
    print(f"Processing fee:                  ${ProcFee:.2f}                ")
    if PayMethod != "Full":
        print(f"Monthly payment (8 months):      ${MonPay:.2f}             ")
    print(f"------------------------------------------                     ")
    print(f"Invoice Date:                   {InvDate.strftime('%Y-%m-%d')} ")
    print(f"First payment date:             {FirPayDate.strftime('%Y-%m-%d')}")
    print(f"------------------------------------------                     ")
    print()
    print()
    print()

    # Display previous claims
    for claim in claims:
        print(f"{'Claim #':<15}{'Claim Date':<15}{'Claim Amount':<15}      ")
        print(f"------------------------------------------                 ")
        print(f"  {claim[0]:<15}{claim[1]:<15}{claim[2]:<15.2f}            ")
        print(f"------------------------------------------                 ")
        print()

    # Makes the policy number go up by one when finishing a claim.
    PolicyNum += 1

    cont = input("Would you like to enter another claim? (Y/N): ").upper()
    if cont == "N":
        break

# Any housekeeping duties at the end of the program.
