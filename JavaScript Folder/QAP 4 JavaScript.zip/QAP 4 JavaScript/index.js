// Desc: Program to create receipts for the members of the St. John's Marina & Yacht Club.
// Author: Landon Lewis
// Dates: Mar 14th - Mar 28th, 2025

var $ = function (id) {
  return document.getElementById(id);
};

// Define format options for printing.
const cur2Format = new Intl.NumberFormat("en-CA", {
  style: "currency",
  currency: "CAD",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const per2Format = new Intl.NumberFormat("en-CA", {
  style: "percent",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const com2Format = new Intl.NumberFormat("en-CA", {
  style: "decimal",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

// Define program constants.
const SITE_EVEN_COST = 80.0;
const SITE_ODD_COST = 120.0;
const ALT_MEM_COST = 5.0;
const SITE_CLEAN = 50.0;
const VIDEO_SURV = 35.0;
const HST = 0.15;
const STAN_DUES = 75.0;
const EXEC_DUES = 150.0;
const PROC_FEE = 59.99;

// Start main program here.

// Gather user inputs.
let curDate = prompt("Enter the current date (YYYY-MM-DD): ");
let siteNum = parseInt(prompt("Enter the site number (1-100): "));
let memName = prompt("Enter the member name: ");
let stAdd = prompt("Enter the member street address: ");
let city = prompt("Enter the member city: ");
let prov = prompt("Enter the member province: ");
let posCode = prompt("Enter the member postal code: ");
let phoneNum = prompt("Enter the member phone number: ");
let cellNum = prompt("Enter the member cell number: ");
let memType = prompt("Enter the membership type (S or E): ");
let altMem = parseInt(prompt("Enter the number of alternate members: "));
let siteClean = prompt("Weekly site cleaning (Y or N): ");
let videoSurv = prompt("Video surveillance (Y or N): ");

// Program Calculations.
let siteCharge =
  (siteNum % 2 === 0 ? SITE_EVEN_COST : SITE_ODD_COST) + altMem * ALT_MEM_COST;

let extraCharges =
  (siteClean.toUpperCase() === "Y" ? SITE_CLEAN : 0) +
  (videoSurv.toUpperCase() === "Y" ? VIDEO_SURV : 0);

let subtot = siteCharge + extraCharges;
let taxes = subtot * HST;
let totMonCharge = subtot + taxes;

let monDues;
if (memType.toUpperCase() === "S") {
  monDues = STAN_DUES;
} else if (memType.toUpperCase() === "E") {
  monDues = EXEC_DUES;
} else {
  alert("Invalid membership type. Monthly dues have been set to $0.00.");
  monDues = 0.0;
}

let totMonFees = totMonCharge + monDues;
let totYearFees = totMonFees * 12;
let monPay = (totMonFees + PROC_FEE) / 12;

let yearSiteCharge = siteCharge * 12;
let canFee = yearSiteCharge * 0.6;

// Outputs for receipt.
const outputHTML = `
  <h1>St. John's Marina & Yacht Club</h1>
  <h2>Yearly Member Receipt</h2>
  <p>-------------------------------------------------------------------------------------------------------</p>


  <p class="client">Client Name and Address:</p>


  <p>-------------------------------------------------------------------------------------------------------</p>
  <p>${memName}</p>
  <p>${stAdd}</p>
  <p>${city}, ${prov} ${posCode}</p>
  <p>Phone: ${phoneNum} (H)</p>
  <p class="cell">${cellNum} (C)</p>
  <p>-------------------------------------------------------------------------------------------------------</p>
  <p>Site #: ${siteNum}                         <span class="memtype">Member type: ${
  memType.toUpperCase() === "S" ? "Standard" : "Executive"
}</span></p>
  <p>-------------------------------------------------------------------------------------------------------</p>

  <p>Alternate members: <span class="value">${altMem}</span></p>
  <p>Weekly site cleaning: <span class="value">${
    siteClean.toUpperCase() === "Y" ? "Yes" : "No"
  }</span></p>
  <p>Video surveillance: <span class="value">${
    videoSurv.toUpperCase() === "Y" ? "Yes" : "No"
  }</span></p>

  <p>-------------------------------------------------------------------------------------------------------</p>

  <p>Site charges: <span class="value">${cur2Format.format(
    siteCharge
  )}</span></p>
  <p>Extra charges: <span class="value">${cur2Format.format(
    extraCharges
  )}</span></p>

  <p>-------------------------------------------------------------------------------------------------------</p>

  <p>Subtotal: <span class="value">${cur2Format.format(subtot)}</span></p>
  <p>Sales tax (HST): <span class="value">${cur2Format.format(taxes)}</span></p>
  <p>-------------------------------------------------------------------------------------------------------</p>

  <p>Total monthly charges: <span class="value">${cur2Format.format(
    totMonCharge
  )}</span></p>
  <p>Monthly dues: <span class="value">${cur2Format.format(monDues)}</span></p>
  <p>-------------------------------------------------------------------------------------------------------</p>

  <p>Total monthly fees: <span class="value">${cur2Format.format(
    totMonFees
  )}</span></p>
  <p>Total yearly fees: <span class="value">${cur2Format.format(
    totYearFees
  )}</span></p>
  <p>-------------------------------------------------------------------------------------------------------</p>

  <p class="monpay">Monthly payment: <span class="value">${cur2Format.format(
    monPay
  )}</span></p>

  <p>-------------------------------------------------------------------------------------------------------</p>

  <p>Issued: <span class="value">${curDate}</span></p>

  <p class="hstreg">HST Reg No: <span class="value">549-33-5849-47</span></p>

  <p>Cancellation fee: <span class="value">${cur2Format.format(
    canFee
  )}</span></p>
`;

// Output Display.
document.getElementById("output").innerHTML = outputHTML;
